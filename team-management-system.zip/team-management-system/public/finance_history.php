<?php
require __DIR__.'/../app/bootstrap.php'; require_login();

/* ستون‌های امور رفاهی ممکن است روی دیتابیس قدیمی هنوز ساخته نشده باشند. */
$finCols = [];
try { foreach ($pdo->query('SHOW COLUMNS FROM financial_transactions') as $c) { $finCols[strtolower($c['Field'])] = true; } } catch (Throwable $e) {}
$itemCols = [];
try { foreach ($pdo->query('SHOW COLUMNS FROM financial_transaction_items') as $c) { $itemCols[strtolower($c['Field'])] = true; } } catch (Throwable $e) {}
$hasTitle  = isset($finCols['welfare_title']);
$hasSeries = isset($finCols['series']);
$hasDetail = isset($itemCols['detail']);

$titleOptions = welfare_title_options();

$where=[]; $params=[];
$allowed=allowed_units();
if(count($allowed)<2){$place=implode(',',array_fill(0,count($allowed),'?'));$where[]="ct.category_key IN ($place)";$params=array_merge($params,$allowed);}

$q=personnel_search_normalize($_GET['q'] ?? '');
if($q!==''){
    [$searchClause,$searchParams]=personnel_search_clause($q,'p');
    if($searchClause!==''){
        $extra=' OR t.reason LIKE ? OR i.iban LIKE ?'.($hasSeries?' OR t.series LIKE ?':'').($hasDetail?' OR i.detail LIKE ?':'');
        $where[]='('.$searchClause.$extra.')';
        foreach($searchParams as $sp) $params[]=$sp;
        $like='%'.$q.'%';
        $params[]=$like; $params[]=$like;
        if($hasSeries) $params[]=$like;
        if($hasDetail) $params[]=$like;
    }
}

/* هر مورد رفاهی یک ردیف است (نه هر عنصر)؛ مبلغ‌ها جمع و نوع‌ها کنار هم نمایش داده می‌شوند. */
$sql='SELECT t.id,t.transfer_type,t.transfer_date,t.reason,t.note,t.created_at'
    .($hasTitle?',t.welfare_title':'')
    .($hasSeries?',t.series':'')
    .',SUM(i.amount) AS amount'
    .($hasDetail?",GROUP_CONCAT(DISTINCT NULLIF(i.detail,'') SEPARATOR '، ') AS detail":'')
    .' FROM financial_transactions t
       JOIN financial_transaction_items i ON i.transaction_id=t.id
       JOIN personnel p ON p.id=i.personnel_id
       JOIN category_types ct ON ct.id=p.category_type_id'
    .($where?' WHERE '.implode(' AND ',$where):'')
    .' GROUP BY t.id,t.transfer_type,t.transfer_date,t.reason,t.note,t.created_at'
    .($hasTitle?',t.welfare_title':'')
    .($hasSeries?',t.series':'')
    .' ORDER BY t.transfer_date DESC,t.id DESC';
$st=$pdo->prepare($sql);$st->execute($params);$rows=$st->fetchAll();

$total=0;
foreach($rows as $r){
    $title=$hasTitle ? (string)$r['welfare_title'] : 'cash';
    if(welfare_is_amount($title)) $total+=(float)$r['amount'];
}
require __DIR__.'/../app/partials/header.php'; ?>
<?php $printTitle='گزارش امور رفاهی عناصر'; $printLandscape=true; require __DIR__.'/../app/partials/print_frame.php'; ?>
<section class="page-head"><div><h1>امور رفاهی</h1></div><div class="report-actions"><button class="btn secondary" type="button" onclick="window.print()">دریافت PDF</button><?php if(can_manage_finance()):?><a class="btn primary" href="finance_form.php">+ ثبت مورد رفاهی</a><?php endif;?></div></section>
<form class="filters" method="get"><?= search_box_html((string)($_GET['q'] ?? ''), 'جستجو نام، کد ملی، بابت یا سری') ?></form>
<div class="cards compact-cards"><div class="stat-card"><span>تعداد موارد رفاهی</span><strong><?=fa_digits((string)count($rows))?></strong></div><div class="stat-card"><span>مجموع مبالغ</span><strong><?=e(format_amount($total))?></strong></div></div>
<div class="panel table-wrap print-list finance-table finance-table-wide"><table>
  <thead><tr>
    <th class="col-row">ردیف</th>
    <th class="col-date">تاریخ</th>
    <th class="col-title">عنوان</th>
    <th class="col-value">نوع یا مبلغ</th>
    <th class="col-reason">بابت</th>
    <th class="col-series">سری</th>
  </tr></thead>
  <tbody>
  <?php $financeRow=0; foreach($rows as $r): $financeRow++;
      $title  = $hasTitle ? (string)$r['welfare_title'] : 'cash';
      $detail = $hasDetail ? (string)($r['detail'] ?? '') : '';
      $series = $hasSeries ? trim((string)($r['series'] ?? '')) : '';
  ?>
    <tr>
      <td class="col-row"><?=fa_digits((string)$financeRow)?></td>
      <td class="col-date"><?=jalali_display($r['transfer_date'])?></td>
      <td class="col-title"><strong><?=e($titleOptions[$title] ?? $title)?></strong></td>
      <td class="col-value"><?=e(welfare_value_text($title, $r['amount'], $detail))?></td>
      <td class="col-reason"><?=e($r['reason']?:'—')?></td>
      <td class="col-series"><?=e($series!=='' ? fa_digits($series) : '—')?></td>
    </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="6" class="empty">موردی ثبت نشده است</td></tr><?php endif; ?>
  </tbody>
</table></div>
<?php require __DIR__.'/../app/partials/footer.php'; ?>
