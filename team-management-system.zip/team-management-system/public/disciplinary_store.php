<?php
require __DIR__ . '/../app/bootstrap.php';
require_login();
if (!can_manage_personnel()) { http_response_code(403); exit('دسترسی غیرمجاز'); }
verify_csrf();

$id = filter_input(INPUT_POST, 'personnel_id', FILTER_VALIDATE_INT);
if (!$id) { http_response_code(400); exit('رکورد نامعتبر است.'); }

$returnTo = 'personnel_view.php?id=' . (int)$id . '&tab=disciplinary';

$reportType   = trim((string)($_POST['report_type'] ?? ''));
$dateInput    = trim((string)($_POST['report_date_jalali'] ?? ''));
$reason       = trim((string)($_POST['reason'] ?? ''));
$issuerName   = trim((string)($_POST['issuer_name'] ?? ''));
$subjectTitle = trim((string)($_POST['subject_title'] ?? ''));

if (!in_array($reportType, ['encouragement','warning','reprimand'], true)) redirect($returnTo . '&disc_error=type');
if ($reason === '' || $subjectTitle === '' || $issuerName === '') redirect($returnTo . '&disc_error=1&disc_type=' . $reportType);
if ($dateInput === '') redirect($returnTo . '&disc_error=date&disc_type=' . $reportType);

$reportDate = parse_jalali_input($dateInput);
if ($reportDate === null) redirect($returnTo . '&disc_error=date&disc_type=' . $reportType);

// برگه سند: برای تشویق/توبیخ الزامی است؛ تذکر برگه ندارد.
$needsDoc = in_array($reportType, ['encouragement','reprimand'], true);
$upload = null;
if (!empty($_FILES['report_document']['name']) && ($_FILES['report_document']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE) {
    $f = $_FILES['report_document'];
    $allowedMime = ['application/pdf'=>'pdf','image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if ($f['error'] !== UPLOAD_ERR_OK || $f['size'] > 8 * 1024 * 1024) redirect($returnTo . '&disc_error=file&disc_type=' . $reportType);
    $mime = (new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    if (!isset($allowedMime[$mime])) redirect($returnTo . '&disc_error=file&disc_type=' . $reportType);
    $upload = ['tmp'=>$f['tmp_name'],'name'=>$f['name'],'mime'=>$mime,'size'=>(int)$f['size'],'ext'=>$allowedMime[$mime]];
}
if ($needsDoc && !$upload) redirect($returnTo . '&disc_error=file&disc_type=' . $reportType);

$st = $pdo->prepare(personnel_select_sql('p') . ' WHERE p.id=?');
$st->execute([$id]);
$person = $st->fetch();
if (!$person || !can_view_unit($person['unit'])) { http_response_code(404); exit('رکورد یافت نشد.'); }
block_if_dismissed($person, 'ثبت پرونده انضباطی');

try {
    $columns = [];
    foreach ($pdo->query('SHOW COLUMNS FROM disciplinary_reports') as $col) { $columns[strtolower($col['Field'])] = $col; }
    if (!isset($columns['subject_title']) || !isset($columns['report_date']) || !isset($columns['issuer_name']) || !isset($columns['document_id'])) {
        throw new RuntimeException('upgrade_v4.41');
    }
    // اگر subject_id هنوز NOT NULL است، مایگریشن کامل اجرا نشده و متن آزاد قابل ثبت نیست.
    if (($columns['subject_id']['Null'] ?? 'NO') !== 'YES') {
        throw new RuntimeException('upgrade_v4.41');
    }

    $pdo->beginTransaction();

    $documentId = null;
    if ($upload) {
        $stored = 'disc_' . (int)$id . '_' . bin2hex(random_bytes(10)) . '.' . $upload['ext'];
        if (!move_uploaded_file($upload['tmp'], storage_path('documents') . $stored)) {
            throw new RuntimeException('ذخیره برگه سند انجام نشد.');
        }
        $insDoc = $pdo->prepare('INSERT INTO personnel_documents(personnel_id,document_type,original_name,stored_name,mime_type,file_size,created_by) VALUES(?,?,?,?,?,?,?)');
        $insDoc->execute([$id, $reportType, $upload['name'], $stored, $upload['mime'], $upload['size'], user()['id'] ?? null]);
        $documentId = (int)$pdo->lastInsertId();
    }

    $ins = $pdo->prepare('INSERT INTO disciplinary_reports(personnel_id,report_type,subject_id,subject_title,issuer_name,report_date,reason,document_id,created_by) VALUES(?,?,NULL,?,?,?,?,?,?)');
    $ins->execute([$id, $reportType, mb_substr($subjectTitle, 0, 120), mb_substr($issuerName, 0, 120), $reportDate, mb_substr($reason, 0, 255), $documentId, user()['id'] ?? null]);

    // هر ۳ تذکر => ۱ توبیخ خودکار، و ۳ توبیخ => برکناری خودکار
    $rules = apply_disciplinary_rules((int)$id, user()['id'] ?? null);
    $pdo->commit();

    $extra = '';
    if ($rules['auto_reprimands'] > 0) $extra .= '&disc_auto=' . (int)$rules['auto_reprimands'];
    if ($rules['dismissed']) $extra .= '&auto_dismissed=1';
    redirect($returnTo . '&disc_saved=' . $reportType . $extra);
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('[disciplinary_store] ' . $e->getMessage());
    $flag = str_contains($e->getMessage(), 'upgrade_v4.41') ? 'schema' : 'save';
    redirect($returnTo . '&disc_error=' . $flag . '&disc_type=' . $reportType);
}
